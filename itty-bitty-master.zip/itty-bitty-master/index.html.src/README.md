Source files for the js/css in index.html
